Approved OAP SMI first-party artwork asset package.

Place both original PNG files in the GitHub repository at the EXACT paths:
static/oap/enter_my_world_wallpaper.png
static/oap/smi_global_intelligence_command_centre.png

The Founder image is a static, decorative login wallpaper behind the EXISTING secure form.
The SMI image is the still command-room scene. Live status, controls and Founder gates remain real HTML/JS.

Do not change image filenames, do not upload the password itself, and do not declare the whole SMI green from artwork alone.
The first-party project PR smi/real-artwork-founder-wallpaper-dashboard expects these assets.
